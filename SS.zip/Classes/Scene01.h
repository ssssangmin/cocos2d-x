#include "cocos2d.h"


class Scene01 : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // implement the "static create()" method manually
    CREATE_FUNC(Scene01);


	void doPushScene(Ref* pSender);
	void doReplaceScene(Ref* pSender);
};

#include "Keyboard.h"

USING_NS_CC;

Scene* Keyboard01::createScene()
{
	return Keyboard01::create();
}

bool Keyboard01::init()
{
	if (!Scene::init())
	{
		return false;
	}

	auto wlayer = LayerColor::create(Color4B::WHITE);
	this->addChild(wlayer);

	// ��������Ʈ
	pSprite = Sprite::
		create("Character/cookie.png");
	pSprite->setPosition(Vec2(640, 360));
	this->addChild(pSprite);

	// ���� �ʱ�ȭ
	_left = _right = _up = _down = false;


	this->scheduleUpdate();
	return true;
}

void Keyboard01::onEnter()
{
	Scene::onEnter();

	_listener = EventListenerKeyboard::create();

	// �ݹ��Լ� ����
	_listener->onKeyPressed =
		CC_CALLBACK_2(Keyboard01::onKeyPressed, this);
	_listener->onKeyReleased =
		CC_CALLBACK_2(Keyboard01::onKeyReleased, this);

	_eventDispatcher->addEventListenerWithSceneGraphPriority
	(_listener, this);

}

void Keyboard01::onExit()
{
	_eventDispatcher->removeEventListener(_listener);

	Scene::onExit();
}

void Keyboard01::onKeyPressed(cocos2d::EventKeyboard::KeyCode keycode,
	cocos2d::Event* event)
{
	switch(keycode)
	{
	case EventKeyboard::KeyCode::KEY_A:
		_left = true;
		break;
	case EventKeyboard::KeyCode::KEY_D:
		_right = true;
		break;
	case EventKeyboard::KeyCode::KEY_W:
		_up = true;
		break;
	case EventKeyboard::KeyCode::KEY_S:
		_down = true;
		break;
	}
}

void Keyboard01::onKeyReleased(cocos2d::EventKeyboard::KeyCode keycode,
	cocos2d::Event* event)
{
	switch (keycode)
	{
	case EventKeyboard::KeyCode::KEY_A:
		_left = false;
		break;
	case EventKeyboard::KeyCode::KEY_D:
		_right = false;
		break;
	case EventKeyboard::KeyCode::KEY_W:
		_up = false;
		break;
	case EventKeyboard::KeyCode::KEY_S:
		_down = false;
		break;
	}
}

void Keyboard01::update(float f)
{
	if (_left)
	{
		// �������� �̵�
		pSprite->setPositionX(pSprite->getPositionX() - 10);
	}
	else if(_right)
	{
		// ���������� �̵�
		pSprite->setPositionX(pSprite->getPositionX() + 10);
	}
	else if (_up)
	{
		// ���� �̵�
		pSprite->setPositionY(pSprite->getPositionY() + 10);
	}
	else if (_down)
	{
		// �Ʒ��� �̵�
		pSprite->setPositionY(pSprite->getPositionY() - 10);
	}
}
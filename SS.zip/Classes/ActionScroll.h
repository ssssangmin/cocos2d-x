#pragma once
#include "cocos2d.h"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
#pragma execution_character_set("utf-8");
#endif

class ActionScroll : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();

	bool init() override;

	CREATE_FUNC(ActionScroll);

	cocos2d::Sprite* pCookie;
	cocos2d::Sprite* pBackground1;
	cocos2d::Sprite* pBackground2;

	void doAction();
};
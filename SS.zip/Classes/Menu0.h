#pragma once
#include "cocos2d.h"

class Menu0 : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();

	bool init() override;

	CREATE_FUNC(Menu0);

	void doClick1(Ref* pSender);
	void doClick2(Ref* pSender);
	void doClick3(Ref* pSender);
};
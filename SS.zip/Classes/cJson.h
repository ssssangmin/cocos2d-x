#include "cocos2d.h"

#include <sstream>
#include <iostream>

#include "json/rapidjson.h"
#include "json/document.h"
#include "json/stringbuffer.h"
#include "json/prettywriter.h"

class cJson : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();

	virtual bool init();

	std::string JsonDocToString(rapidjson::Document & doc, bool isPretty);

	// implement the "static create()" method manually
	CREATE_FUNC(cJson);	
};

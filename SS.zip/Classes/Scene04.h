#include "cocos2d.h"


class Scene04 : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // implement the "static create()" method manually
    CREATE_FUNC(Scene04);

	void doClose(Ref* pSender);

	void doPushSceneTran(Ref* pSender);
	void doReplaceSceneTran(Ref* pSender);
	cocos2d::TransitionScene* createTransition
	(int nIndex, float t, cocos2d::Scene* s);
};

#include "Menu1.h"

USING_NS_CC;

Scene* Menu1::createScene()
{
	return Menu1::create();
}

bool Menu1::init()
{
	if (!Scene::init())
	{
		return false;
	}

	auto wlayer = LayerColor::create(Color4B::WHITE);
	this->addChild(wlayer);


	auto pMenuItem = MenuItemImage::create(
		"Button/btn-play-normal.png",
		"Button/btn-play-selected.png",
		CC_CALLBACK_1(Menu1::doClick, this));

	pMenuItem->setPosition(Vec2(1280, 720));
	pMenuItem->setAnchorPoint(Vec2(1, 1));

	auto pMenu = Menu::create(pMenuItem, nullptr);
	pMenu->setPosition(Vec2::ZERO);

	this->addChild(pMenu);
	
	return true;
}

void Menu1::doClick(Ref* pSender)
{
	log("�޴��� ���õǾ����ϴ�.");
}
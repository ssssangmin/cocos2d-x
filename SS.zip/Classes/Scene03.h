#include "cocos2d.h"


class Scene03 : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // implement the "static create()" method manually
    CREATE_FUNC(Scene03);

	void doClose(Ref* pSender);
};

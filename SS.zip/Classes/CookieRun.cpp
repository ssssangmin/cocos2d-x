#include "CookieRun.h"

USING_NS_CC;

Scene* CookieRun::createScene()
{
	return CookieRun::create();
}

bool CookieRun::init()
{
	if (!Scene::init())
	{
		return false;
	}

	auto wlayer = LayerColor::create(Color4B::WHITE);
	this->addChild(wlayer);

	
}
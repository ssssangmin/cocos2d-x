#include "Scene03.h"
#include "Scene01.h"
#include "Scene04.h"

USING_NS_CC;

Scene* Scene03::createScene()
{
    return Scene03::create();
}

// on "init" you need to initialize your instance
bool Scene03::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

	auto wlayer = 
		LayerColor::create(Color4B::YELLOW);
	this->addChild(wlayer);

	/////////////////////////////
	// �޴� ������ ���� �� �ʱ�ȭ
	auto item1 = MenuItemFont::create(
		"Close Scene 3",
		CC_CALLBACK_1(Scene03::doClose, this));
	item1->setColor(Color3B::BLACK);

	// �޴� ����
	auto pMenu = Menu::create(item1, nullptr);

	pMenu->setPosition(Vec2(640, 360));

	this->addChild(pMenu);
    return true;
}

void Scene03::doClose(Ref* pSender)
{
	_director->getTextureCache()->
		removeUnusedTextures();

	//auto pScene = Scene01::createScene();
	auto pScene = Scene04::createScene();
	Director::getInstance()->
		replaceScene(pScene);
}

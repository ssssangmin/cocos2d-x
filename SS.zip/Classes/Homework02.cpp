#include "Homework02.h"

USING_NS_CC;

Scene* Homework02::createScene()
{
	return Homework02::create();
}

bool Homework02::init()
{
	if (!Scene::init())
	{
		return false;
	}

	auto wlayer = LayerColor::create(Color4B::WHITE);
	this->addChild(wlayer);

	TTFConfig ttfConfig
	("fonts/CookieRun Black.ttf", 40);

	pLabel = Label::createWithTTF(
		ttfConfig, "This font is CookiRun Black");
	pLabel->setPosition(640, 200);
	pLabel->setTextColor(Color4B::BLACK);
	pLabel->setOpacity(0);
	this->addChild(pLabel);

	sprite1 = Sprite::create("Basic/CyanSquare.png");
	sprite1->setPosition(Vec2(400, 360));
	this->addChild(sprite1);

	sprite2 = Sprite::create("Basic/MagentaSquare.png");
	sprite2->setPosition(640, 360);
	this->addChild(sprite2);

	vecSprite.push_back(sprite1);
	vecSprite.push_back(sprite2);

	this->schedule(
		schedule_selector(Homework02::eventUpdate), 0.5f);
}

void Homework02::eventUpdate(float f)
{
	if (pLabel->getStringLength() > currentLetter)
	{
		auto pSprite = pLabel->getLetter(currentLetter);
		if (pSprite != nullptr)
		{
			pSprite->setOpacity(255);
		}

		currentLetter++;
	}
}

void Homework02::onEnter()
{
	Scene::onEnter();

	listener = EventListenerTouchOneByOne::create();

	listener->setSwallowTouches(true);

	listener->onTouchBegan = 
		CC_CALLBACK_2(Homework02::onTouchBegan, this);
	listener->onTouchMoved =
		CC_CALLBACK_2(Homework02::onTouchMoved, this);
	listener->onTouchEnded =
		CC_CALLBACK_2(Homework02::onTouchEnded, this);

	_eventDispatcher->
		addEventListenerWithSceneGraphPriority(listener, sprite1);
	_eventDispatcher->
		addEventListenerWithSceneGraphPriority
		(listener->clone(), sprite2);
}

void Homework02::onExit()
{
	_eventDispatcher->removeAllEventListeners();

	Scene::onExit();
}

bool Homework02::onTouchBegan(cocos2d::Touch * touch, cocos2d::Event * event)
{
	auto target = static_cast<Sprite*>
		(event->getCurrentTarget());

	Vec2 locationInNode = touch->getLocation();
	Size s = target->getContentSize();
	Rect rect = Rect(target->getPosition().x - (s.width / 2),
		target->getPosition().y - (s.height / 2),
		s.width, s.height);

	if (rect.containsPoint(locationInNode))
	{
		target->setOpacity(180);
		return true;
	}

	return false;
}

void Homework02::onTouchMoved(cocos2d::Touch * touch, cocos2d::Event * event)
{
	auto target = static_cast<Sprite*>
		(event->getCurrentTarget());

	target->setPosition(target->getPosition() + touch->getDelta());

	for (int i = 0; i < vecSprite.size(); i++)
	{
		if (target != vecSprite[i])
		{
			this->doCollisionCheck(target, vecSprite[i]);
		}
	}


}

void Homework02::onTouchEnded(cocos2d::Touch * touch, cocos2d::Event * event)
{
}

void Homework02::doCollisionCheck(cocos2d::Sprite * target, cocos2d::Sprite * enemy)
{
	if (target->getBoundingBox().
		intersectsRect(enemy->getBoundingBox()))
	{
		Rect targetRect = target->getBoundingBox();
		Rect spriteRect = enemy->getBoundingBox();

		// ���������� �б�
		if (targetRect.getMaxX() >= spriteRect.getMinX() &&
			targetRect.getMinX() < spriteRect.getMidX() &&
			targetRect.getMinY() + 40 < spriteRect.getMaxY() &&
			targetRect.getMaxY() - 40 > spriteRect.getMinY())
		{
			float deltaPos = targetRect.getMaxX() -
				spriteRect.getMinX();
			enemy->setPosition(enemy->getPosition() + 
				Vec2(deltaPos, 0));
		}

		// �������� �б�
		if (targetRect.getMinX() <= spriteRect.getMaxX() &&
			targetRect.getMinX() > spriteRect.getMidX() &&
			targetRect.getMinY() + 40 < spriteRect.getMaxY() &&
			targetRect.getMaxY() - 40 > spriteRect.getMinY())
		{
			float deltaPos = 
				spriteRect.getMaxX() - targetRect.getMinX();
			enemy->setPosition
			(enemy->getPosition() - Vec2(deltaPos, 0));
		}

		// ���� �б�
		if (targetRect.getMaxY() >= spriteRect.getMinY() &&
			targetRect.getMaxY() < spriteRect.getMidY() &&
			targetRect.getMaxX() - 40 > spriteRect.getMinX() &&
			targetRect.getMinX() + 40 < spriteRect.getMaxX())
		{
			float deltaPos = targetRect.getMaxY() - 
				spriteRect.getMinY();
			enemy->setPosition(enemy->getPosition() +
				Vec2(0, deltaPos));
		}

		// �Ʒ��� �б�
		if (targetRect.getMinY() <= spriteRect.getMaxY() &&
			targetRect.getMaxY() > spriteRect.getMidY() &&
			targetRect.getMaxX() - 40 > spriteRect.getMinX() &&
			targetRect.getMinX() + 40 < spriteRect.getMaxX())
		{
			float deltaPos = 
				spriteRect.getMaxY() - targetRect.getMinY();
			enemy->setPosition(enemy->getPosition() -
				Vec2(0, deltaPos));
		}
	}
}
